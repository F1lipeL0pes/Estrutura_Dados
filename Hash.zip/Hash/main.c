#include <stdio.h>
#include <stdlib.h>

#define TAMANHO1 100

typedef struct No {
    int valor;
    struct No *prox;
} No;

typedef struct Tabela{
    No **vetor;
    int tamanho;
} Tabela;

Tabela *criarTabela(int tamanho) {
    Tabela *T = calloc(1, sizeof(Tabela));

    T->tamanho = tamanho;
    T->vetor = calloc(tamanho, sizeof(No*));

    return T;
}

int funcaoHash(int chave, int tamanho){
    return (unsigned int)chave % tamanho;
}

void inserirTabela(Tabela *T, int chave) {
    if (T == NULL || T->vetor == NULL) return;

    int id = funcaoHash(chave, T->tamanho);

    No *novo = malloc(sizeof(No));

    if (novo == NULL) return;

    novo->valor = chave;
    novo->prox = T->vetor[id];

    T->vetor[id] = novo;
}

int buscar(Tabela *T, int chave) {
    if (T == NULL || T->vetor == NULL) return 0;

    int id = funcaoHash(chave, T->tamanho);

    No *aux = T->vetor[id];

    while (aux != NULL) {
        if (aux->valor == chave) {
            return 1;
        }

        aux = aux->prox;
    }

    return 0;
}

void exibirTabela(Tabela *T) {
    if (T == NULL || T->vetor == NULL) return;

    for (int i = 0; i < T->tamanho; i++) {
        int cont = 0;
        No *aux = T->vetor[i];

        printf("\nLista %d: ", i);

        while (aux != NULL) {
            printf("[%d]:%d -> ", cont, aux->valor);
            cont++;
            aux = aux->prox;
        }

        printf("NULL");
    }
}

void excluirValor(Tabela *T, int chave) {
    if (T == NULL || T->vetor == NULL) return;

    int id = funcaoHash(chave, T->tamanho);

    No *atual = T->vetor[id];
    No *anterior = NULL;

    while (atual != NULL) {
        if (atual->valor == chave) {
            if (anterior == NULL) {
                T->vetor[id] = atual->prox;
            }
            else {
                anterior->prox = atual->prox;
            }
            free(atual);
            return;
        }
        anterior = atual;
        atual = atual->prox;
    }
}

void liberarTabela(Tabela *T) {
    if (T == NULL || T->vetor == NULL) return;

    for (int i = 0; i < T->tamanho; i++) {
        No *atual = T->vetor[i];

        while (atual != NULL) {
            No *aux = atual;
            atual = atual->prox;
            free(aux);
        }
    }

    free(T->vetor);
    T->vetor = NULL;
}

int main()
{
    Tabela *T = criarTabela(8);

    if (T->vetor == NULL) return 1;

    inserirTabela(T, 123);
    inserirTabela(T, 124);
    inserirTabela(T, 125);
    inserirTabela(T, 126);
    inserirTabela(T, 131);

    exibirTabela(T);

    printf("\n\nBuscar 123: %d", buscar(T, 123));

    excluirValor(T, 123);

    printf("\n\nDepois da remocao:");
    exibirTabela(T);

    liberarTabela(T);

    return 0;
}
